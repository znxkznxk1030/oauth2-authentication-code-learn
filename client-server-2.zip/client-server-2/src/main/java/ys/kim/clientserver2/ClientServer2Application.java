package ys.kim.clientserver2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientServer2Application {

	public static void main(String[] args) {
		SpringApplication.run(ClientServer2Application.class, args);
	}

}
